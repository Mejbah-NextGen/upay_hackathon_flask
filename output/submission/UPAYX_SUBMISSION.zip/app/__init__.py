from decimal import Decimal
from pathlib import Path

from flask import Flask, render_template, request, session

from config import DevelopmentConfig, validate_runtime_config
from app.container import build_container, get_container
from app.domain.models import Transaction, User
from app.domain.notifications import NotificationReadState
from app.domain.preferences import UserPreference
from app.domain.profiles import UserProfile
from app.domain.operations import RecipientRegistration, ScheduledPayment
from app.domain.demo import DemoDataset, WalletOpeningBalance
from app.extensions import csrf, db


def create_app(config_object=DevelopmentConfig):
    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object(config_object)
    validate_runtime_config(app)
    if app.config.get("TRUST_PROXY"):
        from werkzeug.middleware.proxy_fix import ProxyFix
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

    Path(app.root_path).parent.joinpath("instance").mkdir(parents=True, exist_ok=True)

    db.init_app(app)
    from app.services.security_service import install_security
    install_security(app)
    csrf.init_app(app)

    from app.blueprints.auth.routes import bp as auth_bp
    from app.blueprints.dashboard.routes import bp as dashboard_bp
    from app.blueprints.wallet.routes import bp as wallet_bp
    from app.blueprints.payments.routes import bp as payments_bp
    from app.blueprints.profile.routes import bp as profile_bp
    from app.blueprints.navigation.routes import bp as navigation_bp
    from app.blueprints.assistant.routes import bp as assistant_bp
    from app.blueprints.insights.routes import bp as insights_bp
    from app.blueprints.operations.routes import bp as operations_bp, register_operations_cli
    from app.blueprints.pilot.routes import bp as pilot_bp, register_pilot_cli
    from app.blueprints.api.routes import bp as api_bp, register_api_cli
    from app.blueprints.observability.routes import bp as observability_bp
    from app.services.worker_service import register_worker_cli
    from app.services.transaction_monitoring_service import register_monitoring_cli

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(wallet_bp)
    app.register_blueprint(payments_bp)
    app.register_blueprint(profile_bp)
    app.register_blueprint(navigation_bp)
    app.register_blueprint(assistant_bp)
    app.register_blueprint(insights_bp)
    app.register_blueprint(operations_bp)
    app.register_blueprint(pilot_bp)
    app.register_blueprint(api_bp)
    app.register_blueprint(observability_bp)
    register_operations_cli(app)
    register_pilot_cli(app)
    register_api_cli(app)
    register_worker_cli(app)
    register_monitoring_cli(app)

    app.extensions["ioc_container"] = build_container(app)

    @app.before_request
    def restore_display_preferences():
        from app.domain.preferences import DisplayPreference
        if request.blueprint in {"api", "observability"}:
            return
        if session.get("user_id") and ("language" not in session or "theme" not in session):
            preferences = db.session.get(DisplayPreference, session["user_id"])
            session.setdefault("language", preferences.language if preferences else "en")
            session.setdefault("theme", preferences.theme if preferences else "system")

    @app.after_request
    def record_pilot_activity(response):
        if (response.status_code == 200 and request.method == "GET"
                and request.endpoint != "static" and request.blueprint not in {"api", "observability"}
                and session.get("user_id")):
            from app.services.pilot_service import record_activity
            if record_activity(session["user_id"]) is not None:
                db.session.commit()
        return response

    @app.after_request
    def localize_html(response):
        from app.services.localization import translate_html
        if session.get("language") == "bn" and response.mimetype == "text/html":
            response.set_data(translate_html(response.get_data(as_text=True)))
        return response

    @app.errorhandler(413)
    def upload_too_large(error):
        return render_template("errors/upload_too_large.html"), 413

    @app.context_processor
    def inject_global_ui():
        from app.auth_helpers import current_user
        from app.services.navigation_service import notification_summary, service_return_target
        from app.services.preference_service import get_preferences
        from app.services.reporting_service import local_datetime
        from app.services.localization import translate, BANGLA

        user = current_user()
        alerts_enabled = bool(user and get_preferences(user.id).notifications_enabled)
        alerts = notification_summary(user.id) if alerts_enabled else {
            "items": [], "unread_count": 0, "read_through": 0, "read_ids": set(),
        }

        return {
            "app_name": app.config["APP_NAME"],
            "currency": app.config["CURRENCY_SYMBOL"],
            "current_user": user,
            "navbar_alerts": alerts,
            "navbar_alerts_enabled": alerts_enabled,
            "service_return": service_return_target(request.args.get("return_to", "")),
            "ui_local_time": local_datetime,
            "profile_details": get_container().profile.get_details(user.id) if user else None,
            "ui_language": session.get("language", "en"),
            "ui_theme": session.get("theme", "system"),
            "t": lambda text: translate(text, session.get("language", "en")),
            "ui_translations": BANGLA if session.get("language") == "bn" else {},
        }

    with app.app_context():
        if app.config.get("AUTO_CREATE_SCHEMA", True):
            db.create_all()
        if app.config.get("SEED_DEMO_DATA", True):
            _seed_demo_data()
            from app.services.demo_seed import seed_demo_operations
            seed_demo_operations(User.query.filter_by(mobile="01329097775").one())

    return app


def _seed_demo_data():
    if User.query.filter_by(mobile="01329097775").first():
        return

    user = User(
        full_name="Md. Mejbahul Islam",
        mobile="01329097775",
        email="mejbah@example.com",
        balance=Decimal("12450.00"),
        verified=True,
    )
    db.session.add(user)
    db.session.flush()

    samples = [
        ("MOBILE_RECHARGE", "OUT", "Mobile Recharge", "Grameenphone • 017XXXXXXXX", "300.00"),
        ("SEND_MONEY", "OUT", "Send Money", "018XXXXXXXX", "500.00"),
        ("BILL_PAYMENT", "OUT", "Bill Payment", "DESCO", "620.00"),
        ("ADD_MONEY", "IN", "Add Money", "Bank Account", "2000.00"),
    ]
    for kind, direction, title, counterparty, amount in samples:
        db.session.add(
            Transaction(
                user_id=user.id,
                kind=kind,
                direction=direction,
                title=title,
                counterparty=counterparty,
                reference=f"DEMO-{kind[:4]}-{user.id}",
                amount=Decimal(amount),
            )
        )
    db.session.commit()
